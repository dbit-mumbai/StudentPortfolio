STEP1:
Run : "localhost/Project/setup/create.php"
on the search window of your browser.(This will create your database and tables)

STEP2:
Run:
"localhost/Project/portfolio.html"
on your browser. This will redirect you to the form. 

STEP3:
The first window is to make a new Entry in the Resprctive Table.
 And Second one is for retrieving the stored Data.